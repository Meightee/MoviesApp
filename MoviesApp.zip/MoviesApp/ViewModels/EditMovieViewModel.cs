namespace MoviesApp.ViewModels
{
    public class EditMovieViewModel:InputMovieViewModel
    {
        
    }
}