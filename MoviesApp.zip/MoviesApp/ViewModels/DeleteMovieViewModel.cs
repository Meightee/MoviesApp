namespace MoviesApp.ViewModels
{
    public class DeleteMovieViewModel:InputMovieViewModel
    {
        
    }
}